from utils.computeBatchMeans import *
from utils.welfordCalculator import *
from lambda_scaler import *
from entity.Pool import *
from entity.Server import *
from utils.utils import truncate_normal
import math

# -------------------- Airport Simulation --------------------
class AirportSimulation:
    def __init__(self, end_time, sampling_rate, type_simulation, model_type, batch_num = 0):
        self.end_time = end_time
        self.metrics = {}
        self.sampling_rate = sampling_rate
        self.batch_num = batch_num
        self.processed_batch = 0
        self.type_simulation = type_simulation
        self.model_type = model_type
        self.times = Times()
        self.event_list = []
        self.servers = []
        self.server_pools = {}
        self.completed_jobs = 0
        self.arrivals = 0
        self.passenger_routing = {}
        self.total_queues_check_in = []
        self.total_queues_security = []
        self.counter = 0
        self.last_arrival_time = {}
        self.current_slot = None
        self.time_slots = [
            (0, 359*60 + 59         , "night"),
            (360*60, 539*60 +59     , "morning"),
            (540*60, 719*60   +59  , "late_morning"),
            (720*60, 899*60  +59   , "early_afternoon"),
            (900*60, 1139*60 +59   , "late_afternoon"),
            (1140*60, 1319*60 +59  , "evening"),
            (1320*60, 1440*60 +59  , "late_evening"),
         ]
        self.lambdas = {}
        self.next_sampling = self.sampling_rate
        self.init_servers_and_pools()
        self.init_time_slot_events()
        if self.type_simulation == "finite":
            self.init_sampling_events()

    def reset_sistem(self):
        for pool in self.server_pools.values():
            pool.reset_pool()
        self.completed_jobs = 0
        self.event_list.clear()
        self.times.current = 0
        self.times.next = 0.0
        self.init_time_slot_events()

    # -------------------- Time slots --------------------
    def init_time_slot_events(self):
        for start, end, name in self.time_slots:
            if start <= self.end_time:
                heapq.heappush(self.event_list, (start, "H", name))
        self.update_current_slot(0)

    def init_sampling_events(self):
        while self.next_sampling <= self.end_time:
                heapq.heappush(self.event_list, (self.next_sampling, "S", "sampling_event"))
                self.next_sampling += self.sampling_rate

    def update_current_slot(self, current_time):
        for start, end, name in self.time_slots:
            if start <= current_time < end:
                self.current_slot = name
                lambda_scaler = LambdaScaler()
                if self.type_simulation == "finite":
                    self.lambdas = lambda_scaler.return_new_lambdas(time_slot = self.current_slot, model_type= self.model_type)
                else : self.lambdas = lambda_scaler.return_new_lambdas(model_type = self.model_type, lambda_to_use=None, time_slot= "late_afternoon")
                break

    # -------------------- Servers & Pools --------------------
    def init_servers_and_pools(self):

        match self.model_type:
            case "improved":
                self.server_pools = {
                    "business_a": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"business_a_{index}", self.type_simulation) for index in range(1)]),
                    "premium_economy_a": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"premium_economy_a_{index}", self.type_simulation) for index in range(1)]),
                    "economy_a": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"economy_a_{index}", self.type_simulation) for index in range(3)]),
                    "flexi_plus_a": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"flexi_plus_a_{index}", self.type_simulation) for index in range(1)]),
                    "self_bd_a": MultiServerSingleQueuePool(
                        [BagDropCheckInServer(f"self_bd_a_{index}", self.type_simulation) for index in range(1)]),
                    "bd_a": MultiServerSingleQueuePool(
                        [BagDropCheckInServer(f"bd_a_{index}", self.type_simulation) for index in range(4)]),

                    "business_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"business_b_{index}", self.type_simulation) for index in range(1)]),
                    "premium_economy_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"premium_economy_b_{index}", self.type_simulation) for index in range(1)]),
                    "economy_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"economy_b_{index}", self.type_simulation) for index in range(2)]),
                    "check_in_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"check_in_b_{index}", self.type_simulation) for index in range(1)]),
                    "bd_b": MultiServerSingleQueuePool(
                        [BagDropCheckInServer(f"bd_b_{index}", self.type_simulation) for index in range(1)]),

                    "business_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"business_c_{index}", self.type_simulation) for index in range(1)]),
                    "premium_economy_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"premium_economy_c_{index}", self.type_simulation) for index in range(1)]),
                    "economy_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"economy_c_{index}", self.type_simulation) for index in range(2)]),
                    "check_in_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"check_in_c_{index}", self.type_simulation) for index in range(1)]),
                    "bd_c": MultiServerSingleQueuePool(
                        [BagDropCheckInServer(f"bd_c_{index}", self.type_simulation) for index in range(1)]),

                    "fast_track_turnstile": MultiServerSingleQueuePool(
                        [TurnstileServer("fast_track_turnstile_0", self.type_simulation)]),
                    "fast_track_security_area": MultiServerSingleQueuePool(
                        [SecurityCheckServer(f"fast_track_sec_{index}", self.type_simulation) for index in range(4)]),
                    "turnstiles": MultiServerMultiQueuesPool(
                        [TurnstileServer(f"turnstile_{index}", self.type_simulation) for index in range(4)]),
                    "security_area": MultiServerSingleQueuePool(
                        [SecurityCheckServer(f"security_{index}", self.type_simulation) for index in range(3)]),
                    "fast_security_area": MultiServerSingleQueuePool(
                        [FastSecurityCheckServer(f"fast_security_{index}", self.type_simulation) for index in range(3)]),
                }

                self.passenger_routing = {
                    "business_a": PassengerType("Business_a", self.server_pools["business_a"],
                                                next_center="fast_track_turnstile"),
                    "premium_economy_a": PassengerType("PremiumEconomy_a", self.server_pools["premium_economy_a"],
                                                       next_center="turnstile_area"),
                    "economy_a": PassengerType("Economy_a", self.server_pools["economy_a"], next_center="turnstile_area"),
                    "flexi_plus_a": PassengerType("FlexiPlus_a", self.server_pools["flexi_plus_a"],
                                                  next_center="fast_track_turnstile"),
                    "self_bd_a": PassengerType("SelfBD_a", self.server_pools["self_bd_a"], next_center="turnstile_area"),
                    "bd_a": PassengerType("BD_a", self.server_pools["bd_a"], next_center="turnstile_area"),

                    "business_b": PassengerType("Business_b", self.server_pools["business_b"],
                                                next_center="fast_track_turnstile"),
                    "premium_economy_b": PassengerType("PremiumEconomy_b", self.server_pools["premium_economy_b"],
                                                       next_center="turnstile_area"),
                    "economy_b": PassengerType("Economy_b", self.server_pools["economy_b"], next_center="turnstile_area"),
                    "check_in_b": PassengerType("CheckIn_b", self.server_pools["check_in_b"], next_center="turnstile_area"),
                    "bd_b": PassengerType("BD_b", self.server_pools["bd_b"], next_center="turnstile_area"),

                    "business_c": PassengerType("Business_C", self.server_pools["business_c"],
                                                next_center="fast_track_turnstile"),
                    "premium_economy_c": PassengerType("PremiumEconomy_c", self.server_pools["premium_economy_c"],
                                                       next_center="turnstile_area"),
                    "economy_c": PassengerType("Economy_c", self.server_pools["economy_c"], next_center="turnstile_area"),
                    "check_in_c": PassengerType("CheckIn_c", self.server_pools["check_in_c"], next_center="turnstile_area"),
                    "bd_c": PassengerType("BD_c", self.server_pools["bd_c"], next_center="turnstile_area"),

                    "fast_track_turnstile": PassengerType("FastTrackTurnstile", self.server_pools["fast_track_turnstile"],
                                                          next_center="fast_track_security_area"),
                    "fast_track_security_area": PassengerType("FastTrackSecurity",
                                                              self.server_pools["fast_track_security_area"]),
                    "turnstile": PassengerType("Turnstile", self.server_pools["turnstiles"], next_center="security_area"),
                    "security_area": PassengerType("Security", self.server_pools["security_area"]),
                    "fast_security_area": PassengerType("FastSecurity", self.server_pools["fast_security_area"])
                }
            case _:
                self.server_pools = {
                    "business_a": MultiServerSingleQueuePool([ClassicCheckInServer(f"business_a_{index}", self.type_simulation) for index in range(1)]),
                    "premium_economy_a": MultiServerSingleQueuePool([ClassicCheckInServer(f"premium_economy_a_{index}", self.type_simulation) for index in range(1)]),
                    "economy_a": MultiServerSingleQueuePool([ClassicCheckInServer(f"economy_a_{index}", self.type_simulation) for index in range(3)]),
                    "flexi_plus_a": MultiServerSingleQueuePool([ClassicCheckInServer(f"flexi_plus_a_{index}", self.type_simulation) for index in range(1)]),
                    "self_bd_a": MultiServerSingleQueuePool([BagDropCheckInServer(f"self_bd_a_{index}", self.type_simulation) for index in range(1)]),
                    "bd_a": MultiServerSingleQueuePool([BagDropCheckInServer(f"bd_a_{index}", self.type_simulation) for index in range(4)]),

                    "business_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"business_b_{index}", self.type_simulation) for index in range(1)]),
                    "premium_economy_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"premium_economy_b_{index}", self.type_simulation) for index in range(1)]),
                    "economy_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"economy_b_{index}", self.type_simulation) for index in range(2)]),
                    "check_in_b": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"check_in_b_{index}", self.type_simulation) for index in range(1)]),
                    "bd_b": MultiServerSingleQueuePool(
                        [BagDropCheckInServer(f"bd_b_{index}", self.type_simulation) for index in range(1)]),

                     "business_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"business_c_{index}", self.type_simulation) for index in range(1)]),
                    "premium_economy_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"premium_economy_c_{index}", self.type_simulation) for index in range(1)]),
                    "economy_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"economy_c_{index}", self.type_simulation) for index in range(2)]),
                    "check_in_c": MultiServerSingleQueuePool(
                        [ClassicCheckInServer(f"check_in_c_{index}", self.type_simulation) for index in range(1)]),
                    "bd_c": MultiServerSingleQueuePool(
                        [BagDropCheckInServer(f"bd_c_{index}", self.type_simulation) for index in range(1)]),

                    "fast_track_turnstile": MultiServerSingleQueuePool([TurnstileServer("fast_track_turnstile_0", self.type_simulation)]),
                    "fast_track_security_area": MultiServerSingleQueuePool([SecurityCheckServer(f"fast_track_sec_{index}", self.type_simulation) for index in range(3)]),
                    "turnstiles": MultiServerMultiQueuesPool([TurnstileServer(f"turnstile_{index}", self.type_simulation) for index in range(4)]),
                    "security_area": MultiServerSingleQueuePool([SecurityCheckServer(f"security_{index}", self.type_simulation) for index in range(7)])
                }

                self.passenger_routing = {
                    "business_a": PassengerType("Business_a", self.server_pools["business_a"], next_center="fast_track_turnstile"),
                    "premium_economy_a": PassengerType("PremiumEconomy_a", self.server_pools["premium_economy_a"], next_center="turnstile_area"),
                    "economy_a": PassengerType("Economy_a", self.server_pools["economy_a"], next_center="turnstile_area"),
                    "flexi_plus_a": PassengerType("FlexiPlus_a", self.server_pools["flexi_plus_a"], next_center="fast_track_turnstile"),
                    "self_bd_a": PassengerType("SelfBD_a", self.server_pools["self_bd_a"], next_center="turnstile_area"),
                    "bd_a": PassengerType("BD_a", self.server_pools["bd_a"], next_center="turnstile_area"),

                    "business_b": PassengerType("Business_b", self.server_pools["business_b"], next_center="fast_track_turnstile"),
                    "premium_economy_b": PassengerType("PremiumEconomy_b", self.server_pools["premium_economy_b"], next_center="turnstile_area"),
                    "economy_b": PassengerType("Economy_b", self.server_pools["economy_b"], next_center="turnstile_area"),
                    "check_in_b": PassengerType("CheckIn_b", self.server_pools["check_in_b"], next_center="turnstile_area"),
                    "bd_b": PassengerType("BD_b", self.server_pools["bd_b"], next_center="turnstile_area"),


                    "business_c": PassengerType("Business_C", self.server_pools["business_c"], next_center="fast_track_turnstile"),
                    "premium_economy_c": PassengerType("PremiumEconomy_c", self.server_pools["premium_economy_c"], next_center="turnstile_area"),
                    "economy_c": PassengerType("Economy_c", self.server_pools["economy_c"], next_center="turnstile_area"),
                    "check_in_c": PassengerType("CheckIn_c", self.server_pools["check_in_c"], next_center="turnstile_area"),
                    "bd_c": PassengerType("BD_c", self.server_pools["bd_c"], next_center="turnstile_area"),



                    "fast_track_turnstile": PassengerType("FastTrackTurnstile", self.server_pools["fast_track_turnstile"], next_center="fast_track_security_area"),
                    "fast_track_security_area": PassengerType("FastTrackSecurity", self.server_pools["fast_track_security_area"]),
                    "turnstile": PassengerType("Turnstile", self.server_pools["turnstiles"], next_center="security_area"),
                    "security_area": PassengerType("Security", self.server_pools["security_area"])
                }

        for pool_name, pool in self.server_pools.items():
                if isinstance(pool, MultiServerSingleQueuePool):
                    self.metrics[pool_name] = []
                else:
                    self.metrics[pool_name] = {srv.name: [] for srv in pool.servers}
        self.metrics["daily_percentile_90_wait"] = []
        self.metrics["replica_mean_check"] = 0.0
        self.metrics["replica_mean_sec"] = 0.0

    # -------------------- Interarrival --------------------
    def generate_interarrival_time(self, op_index):
      lambda_rescaled = self.lambdas[op_index]
      if op_index == "turnstile_area":
          delay = truncate_normal(240, math.sqrt(30), 180, 300)
          return exponential(1 / lambda_rescaled) + delay
      else :
        return exponential(1 / lambda_rescaled)

    # -------------------- Arrival processing --------------------
    def process_arrival(self, event):
        op = event.op_index
        input_flow_zone_a = ["business_a", "premium_economy_a", "economy_a", "flexi_plus_a", "self_bd_a", "bd_a", "business_b", "premium_economy_b", "economy_b", "check_in_b", "bd_b", "business_c", "premium_economy_c", "economy_c", "check_in_c", "bd_c"]

        if op == "turnstile_area" and event.nums_hops == 0:
            self.arrivals +=1
            self.generate_new_arrival(op)

        if op in input_flow_zone_a:
            self.arrivals += 1
            self.generate_new_arrival(op)

        if op == "turnstile_area":
            select_stream(20)
            r2 = random()
            choice = "fast" if r2 <= 0.25 else "normal"

            if choice == "fast" and event.check_in_done == False:
                pool = self.server_pools["fast_track_turnstile"]
                event.next_center = "fast_track_security_area"
                event.op_index = "fast_track_turnstile"

            else:  # normal
                pool = self.server_pools["turnstiles"]
                event.op_index = "turnstile"
                if self.model_type == "improved":
                    if event.check_in_done:
                        event.next_center = "fast_security_area"
                    else:
                        event.next_center = "security_area"
                else : event.next_center = "security_area"

            #print(f"  [ROUTING] {op} passenger → {choice} priority")
            if isinstance(pool, MultiServerMultiQueuesPool) and self.type_simulation == "infinite":
                pool.assign_event_infinite(event, self.event_list, self.times)
            else:
                pool.assign_event(event, self.event_list, self.times, op)
            return
        else :
            ptype = self.passenger_routing[op]
            pool = ptype.server_pool
            if isinstance(pool, MultiServerMultiQueuesPool) and self.type_simulation == "infinite":
                pool.assign_event_infinite(event, self.event_list, self.times)
            else:
                pool.assign_event(event, self.event_list, self.times, op)
            if ptype.next_center:
                event.next_center = ptype.next_center

    # -------------------- Generate new arrivals --------------------
    def generate_new_arrival(self, op_index=None):
        select_stream({
          "business_a": 10, "premium_economy_a": 11, "economy_a": 12,
          "flexi_plus_a": 13, "self_bd_a": 14, "bd_a": 15,

          "business_b": 50, "premium_economy_b": 51, "economy_b": 52,
          "check_in_b": 53,  "bd_b": 55,

          "business_c": 80, "premium_economy_c": 81, "economy_c": 82,
          "check_in_c": 83, "bd_c": 85,

          "turnstile_area": 86

        }[op_index])
        interarrival = self.generate_interarrival_time(op_index)

        event_time = self.last_arrival_time[op_index] + interarrival
        event = Event(event_time, "A", op_index)
        if op_index == "turnstile_area":
            select_stream(126)
            r = random()
            if r <= 0.25:
                event.check_in_done = True
        self.last_arrival_time[op_index] = event_time
        if event_time <= self.end_time:
            heapq.heappush(self.event_list, (event_time, "A", event))

    # -------------------- Process next event --------------------
    def process_next_event(self):
        if not self.event_list:
            return None, None

        item = heapq.heappop(self.event_list)

        if len(item) == 3:
            time_event, event_type, event = item
            server = None
        else:
            time_event, event_type, server, event = item

        self.times.next = time_event

        if event_type == "A":
            self.process_arrival(event)
        elif event_type == "C" and server is not None:
            ptype = self.passenger_routing.get(event.op_index)
            pool = ptype.server_pool if ptype else None

            if isinstance(pool, MultiServerMultiQueuesPool):
                isMultiServerMultiQueues = True
            else:
                isMultiServerMultiQueues = False

            server.handle_departure(event, self.event_list, model_type = self.model_type, isMultiServerMultiQueues= isMultiServerMultiQueues, pool=pool, times=self.times)
            if ptype and ptype.name == "Security" or ptype.name == "FastTrackSecurity":
                self.completed_jobs += 1
        elif event_type == "H":
            self.update_current_slot(time_event)
        elif event_type == "S":
            self.collect_metrics()

        return event_type, event

    # -------------------- Metrics --------------------
    def collect_metrics(self):
        current_time = self.times.next

        for pool_name, pool in self.server_pools.items():
            if pool_name ==  "turnstiles" :
                lambda_rescaled = self.lambdas["security_area"]
            elif pool_name == "fast_track_turnstile":
                lambda_rescaled = self.lambdas["fast_track_security_area"]
            else:
                lambda_rescaled = self.lambdas[pool_name]

            # ------------------- Metrics per server -------------------
            if isinstance(pool, MultiServerMultiQueuesPool):
                for s in pool.servers:
                    completed = len(s.completed)
                    if completed > 0:
                        avg_queue_s = s.avg_wait_time()
                        avg_service_s = (s.total_busy_time / completed) if completed > 0 else 0.0
                        avg_resp_s = avg_queue_s + avg_service_s
                        snapshot_s = {
                            "time": current_time,
                            "queue_length": len(s.queue),
                            "in_system": s.num_in_system,
                            "avg_utilization": s.utilization(current_time),
                            "avg_waiting_time": avg_queue_s,
                            "avg_response_time": avg_resp_s,
                            "avg_queue_population": (lambda_rescaled / len(pool.servers)) * avg_queue_s,
                            "avg_system_population": (lambda_rescaled / len(pool.servers)) * avg_resp_s,
                            "passengers_completed": self.completed_jobs,
                        }
                        self.metrics[pool_name][s.name].append(snapshot_s)
            else :
                # ------------------- Pool metrics -------------------
                service_total = 0.0
                total_completed = 0
                queue_total = 0.0

                for s in pool.servers:
                    completed = len(s.completed)
                    total_completed += completed
                    queue_total += s.avg_wait_time()
                    service_total += (s.total_busy_time / completed) if completed > 0 else 0.0

                if total_completed > 0:
                    avg_queue = queue_total
                    avg_service = service_total / len(pool.servers) if len(pool.servers) > 0 else 0
                    avg_resp = avg_queue + avg_service

                    # --- Lunghezza coda ---
                    if isinstance(pool, MultiServerMultiQueuesPool):
                        queue_len = sum(len(s.queue) for s in pool.servers)
                    else:
                        queue_len = len(pool.queue)

                    # --- Snapshot pool ---
                    snapshot = {
                        "time": current_time,
                        "queue_length": queue_len,
                        "in_system": pool.total_in_system(),
                        "avg_utilization": pool.avg_utilization(current_time),
                        "avg_waiting_time": avg_queue,
                        "avg_response_time": avg_resp,
                        "avg_queue_population": lambda_rescaled * avg_queue,
                        "avg_system_population": lambda_rescaled * avg_resp,
                        "passengers_completed": self.completed_jobs,
                    }

                    self.metrics[pool_name].append(snapshot)


            self.total_queues_security = []
            self.total_queues_check_in = []
            for _, pools in self.server_pools.items():
                for server in pools.servers:
                    if isinstance(server, SecurityCheckServer) or isinstance(server, FastSecurityCheckServer):
                        self.total_queues_security.extend(server.queue_waits)
                    if isinstance(server, ClassicCheckInServer) or isinstance(server, BagDropCheckInServer):
                        self.total_queues_check_in += server.queue_waits
            if len(self.total_queues_security) > 0 and len(self.total_queues_check_in) > 0:
                percentile_90_sec = np.percentile(self.total_queues_security, 90)
                percentile_90_check = np.percentile(self.total_queues_check_in, 90)

                snapshot_perc = {
                    "time": current_time,
                    "security": percentile_90_sec,
                    "check_in": percentile_90_check,
                }
                self.metrics["daily_percentile_90_wait"].append(snapshot_perc)

    # -------------------- Run --------------------
    def run(self):
        _, _ = self.process_next_event()

        self.last_arrival_time = {k: 0.0 for k in
                                  ["business_a", "premium_economy_a", "economy_a", "flexi_plus_a", "self_bd_a", "bd_a", "business_b", "premium_economy_b", "economy_b", "check_in_b", "bd_b", "business_c", "premium_economy_c", "economy_c", "check_in_c", "bd_c", "turnstile_area"]
                                }

        # Genera un arrivo iniziale per ogni centro (tipo di passeggero)
        for op_index in ["business_a", "premium_economy_a", "economy_a", "flexi_plus_a", "self_bd_a", "bd_a", "business_b", "premium_economy_b", "economy_b", "check_in_b", "bd_b", "business_c", "premium_economy_c", "economy_c", "check_in_c", "bd_c", "turnstile_area"]:
            self.generate_new_arrival(op_index)

        if self.type_simulation == "finite":
            while self.event_list and self.times.next <= self.end_time:
                self.process_next_event()

            ################ CALCOLO WELFORD MEDIA E DEVIAZIONE STANDARD ####################
            _, mean_checkIn, _ = compute_metrics_welford(self.total_queues_check_in)
            _, mean_Security, _ = compute_metrics_welford(self.total_queues_security)

            self.metrics["replica_mean_check"] = mean_checkIn
            self.metrics["replica_mean_Security"] = mean_Security

        else :
            while self.processed_batch < self.batch_num:
                self.process_next_event()


                if self.completed_jobs == self.sampling_rate and self.completed_jobs != 0:
                    self.collect_metrics()
                    self.processed_batch += 1
                    print(f"Batch {self.processed_batch}/{self.batch_num}")

                    self.reset_sistem()

                    self.last_arrival_time = {k: 0.0 for k in ["business_a", "premium_economy_a", "economy_a", "flexi_plus_a", "self_bd_a", "bd_a", "business_b", "premium_economy_b", "economy_b", "check_in_b", "bd_b", "business_c", "premium_economy_c", "economy_c", "check_in_c", "bd_c", "turnstile_area"
                                ]}
                    for op_index in ["business_a", "premium_economy_a", "economy_a", "flexi_plus_a", "self_bd_a", "bd_a", "business_b", "premium_economy_b", "economy_b", "check_in_b", "bd_b", "business_c", "premium_economy_c", "economy_c", "check_in_c", "bd_c", "turnstile_area"]:
                        self.generate_new_arrival(op_index)
            for key, value in self.metrics.items():
                print(f"\nComputing area {key}")
                compute_batch_means_cis(value, key)
        return self.metrics