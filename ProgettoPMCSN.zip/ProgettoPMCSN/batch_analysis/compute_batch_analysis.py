import numpy as np

def autocorr(x):
    """Autocorrelazione al lag 1"""
    x_mean = np.mean(x)
    num = np.sum((x[:-1] - x_mean) * (x[1:] - x_mean))
    den = np.sum((x - x_mean)**2)
    return num / den

def find_batch_size(values, target_autocorr=0.2):
    """Trova b usando ricerca binaria"""
    left = 1
    right = len(values) // 2  # massimo batch metà dei dati
    best_b = 1

    while left <= right:
        b = (left + right) // 2
        k = len(values) // b
        if k < 2:
            right = b - 1
            continue

        batch_means = np.array([np.mean(values[i*b:(i+1)*b]) for i in range(k)])
        r = autocorr(batch_means)

        if r <= target_autocorr:
            best_b = b
            right = b - 1  # prova batch più piccoli
        else:
            left = b + 1  # batch troppo piccolo, aumenta b

    return best_b, len(values) // best_b