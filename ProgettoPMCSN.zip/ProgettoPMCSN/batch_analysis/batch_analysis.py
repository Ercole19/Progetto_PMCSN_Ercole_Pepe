from simulation import AirportSimulation
from libs.rng import *

# === Parametri iniziali "di esplorazione" ===
SAMPLING_RATE = 256          # Ogni quanti job si campiona (b provvisorio)
BATCH_NUM = 8192            # Numero di batch provvisori (deve essere alto)
SEED = 123456789

def extract_all_metrics(metrics, metric_names):
    data_dict = {metric: [] for metric in metric_names}
    for metric_name in metric_names:
        for center_name, center_batches in metrics.items():
            if isinstance(center_batches, float):
                continue
            if isinstance(center_batches, dict):
                for key in center_batches:
                    for batch in center_batches[key]:
                        if isinstance(batch, dict) and metric_name in batch and  batch[metric_name] is not None:
                            data_dict[metric_name].append(batch[metric_name])
            else :
                for batch in center_batches:
                    if isinstance(batch, dict) and metric_name in batch and batch[metric_name] is not None:
                        data_dict[metric_name].append(batch[metric_name])
    return data_dict



if __name__ == '__main__':

    plant_seeds(SEED)

    # === Avvia simulazione iniziale ===
    sim = AirportSimulation(
        end_time=float('inf'),
        sampling_rate=SAMPLING_RATE,
        type_simulation="infinite",
        batch_num=BATCH_NUM,
        model_type = "no_improved",
    )

    print("Esecuzione simulazione preliminare...")
    metrics = sim.run()
    print("Simulazione completata.")

    metrics_to_analyze = [
        "avg_utilization",
        "avg_waiting_time",
        "avg_response_time",
        "avg_queue_population",
        "avg_system_population"
    ]

    data_dict = extract_all_metrics(metrics, metrics_to_analyze)
    #b, k = find_batch_size(data_dict["avg_waiting_time"])
    with open("../libs/autocorrelation_data.txt", "w") as f:
        for x in data_dict["avg_waiting_time"]:
            f.write(f"{x}\n")

    print(f"File di autocorrelazione costruito, eseguire acs.py")