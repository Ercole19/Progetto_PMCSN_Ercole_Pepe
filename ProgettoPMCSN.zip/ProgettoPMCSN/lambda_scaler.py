class LambdaScaler:
    def __init__(self):
        self.total_daily_passengers =  14761 * 2 * 0.55

        ############# ZONA CHECK IN A #####################
        self.P_T_A = 0.2              # Probabilità che un passeggero scelga una compagnia Tradizionale
        self.P_L_A = 0.8              # Probabilità che un passeggero scelga una compagnia Low-Cost

        self.P_T_B_A = 0.05  # Probabilità che un passeggero scelga la tariffa Business-Class
        self.P_T_PE_A = 0.1  # Probabilità che un passeggero scelga la tariffa Premium-Economy
        self.P_T_E_A = 0.5  # Probabilità che un passeggero scelga la tariffa Economy
        self.P_T_OB_A = 0.35  # Probabilità che un passeggero abbia effettuato check-in online e non abbia il bagaglio da stiva

        self.P_L_OB_A = 0.7  # Probabilità che un passeggero non abbia il bagaglio da stiva
        self.P_L_NOB_A = 1 - self.P_L_OB_A  # Probabilità che un passeggero richieda servizi aggiuntivi

        self.P_L_FP_A = 0.05  # Probabilità che un passeggero abbia scelto il servizio Flexi-Plus
        self.P_L_SB_e_D_A = 0.1  # Probabilità che un passeggero esegue autonomamente l'imbarco del bagaglio da stiva
        self.P_L_B_e_D_A = 0.85  # Probabilità che un passeggero non esegue autonomamente l'imbarco del bagaglio da stiva

        ############# ZONA CHECK IN B #####################
        self.P_T_B = 0.45  # Probabilità che un passeggero scelga una compagnia Tradizionale
        self.P_L_B = 0.55  # Probabilità che un passeggero scelga una compagnia Low-Cost

        self.P_T_B_B = 0.1  # Probabilità che un passeggero scelga la tariffa Business-Class
        self.P_T_PE_B = 0.15  # Probabilità che un passeggero scelga la tariffa Premium-Economy
        self.P_T_E_B = 0.5     # Probabilità che un passeggero scelga la tariffa Economy
        self.P_T_OB_B = 0.25  # Probabilità che un passeggero abbia effettuato check-in online e non abbia il bagaglio da stiva

        self.P_L_OB_B = 0.6  # Probabilità che un passeggero non abbia il bagaglio da stiva
        self.P_L_NOB_B = 1 - self.P_L_OB_B  # Probabilità che un passeggero richieda servizi aggiuntivi

        self.P_L_C_B = 0.3  # Probabilità che un passeggero vada al desk check-in
        self.P_L_BD_B = 0.7  # Probabilità che un passeggero vada al desk bag&drop per depositare il bagaglio

        ############# ZONA CHECK IN C #####################
        self.P_T_C = 0.45  # Probabilità che un passeggero scelga una compagnia Tradizionale
        self.P_L_C = 0.55  # Probabilità che un passeggero scelga una compagnia Low-Cost

        self.P_T_B_C = 0.1  # Probabilità che un passeggero scelga la tariffa Business-Class
        self.P_T_PE_C = 0.15  # Probabilità che un passeggero scelga la tariffa Premium-Economy
        self.P_T_E_C = 0.5  # Probabilità che un passeggero scelga la tariffa Economy
        self.P_T_OB_C = 0.25  # Probabilità che un passeggero abbia effettuato check-in online e non abbia il bagaglio da stiva

        self.P_L_OB_C = 0.6  # Probabilità che un passeggero non abbia il bagaglio da stiva
        self.P_L_NOB_C = 1 - self.P_L_OB_C  # Probabilità che un passeggero richieda servizi aggiuntivi

        self.P_L_C_C = 0.3  # Probabilità che un passeggero vada al desk check-in
        self.P_L_BD_C = 0.7  # Probabilità che un passeggero vada al desk bag&drop per depositare il bagaglio

        ############# TORNELLI E CONTROLLI DI SICUREZZA ###################
        self.P_FT_NI = 0.25


        self.slots_duration = {
            "night" : 360*60,
            "morning" : 180*60,
            "late_morning" : 180*60,
            "early_afternoon" : 180*60,
            "late_afternoon" : 180*60,
            "evening" : 180*60,
            "late_evening" : 180*60
        }
        self.lambdas = {
            "business": 0.0,
            "premium_economy": 0.0,
            "economy": 0.0,
            "flexi_plus": 0.0,
            "self_bd": 0.0,
            "bd": 0.0,
            "turnstile_area": 0.0,
            "exogenous": 0.0,
            "fast_track_turnstile": 0.0,
            "security_area": 0.0,
            "fast_track_security_area": 0.0,
        }
        self.percent = {
            "night":0.066,
            "morning": 0.165,
            "late_morning": 0.165,
            "early_afternoon": 0.165,
            "late_afternoon": 0.196,
            "evening": 0.165,
            "late_evening": 0.078
        }

    def return_new_lambdas(self, time_slot, model_type, lambda_to_use = None):
        if time_slot is None:
            self.calculate_lambdas(lambda_to_use, model_type)
        else:
            num_of_passenger_in_slot = self.total_daily_passengers * (self.percent.get(time_slot)) #Passeggeri che arrivano in quella fascia oraria
            lambda_total_slot = num_of_passenger_in_slot / (self.slots_duration[time_slot]) #Tasso globale in ingresso al sistema in quella fascia oraria
            self.calculate_lambdas(lambda_total_slot, model_type)
        return self.lambdas

    def calculate_lambdas(self, lambda_total, model_type):
        GAMMA = lambda_total  # Tasso medio complessivo degli arrivi

        LAMBDA_A = GAMMA * 0.6  #Tasso medio complessivo degli arrivi alla zona Check-In A
        LAMBDA_B = GAMMA * 0.2  #Tasso medio complessivo degli arrivi alla zona Check-In B
        LAMBDA_C = GAMMA * 0.2  #Tasso medio complessivo degli arrivi alla zona Check-In C

        ################ ZONA CHECK IN A  ###################
        # -------------------- Check-In tradizionale --------------
        LAMBDA_T_A = LAMBDA_A * self.P_T_A
        LAMBDA_BC_A = LAMBDA_T_A * self.P_T_B_A  # Tasso medio d'arrivo al centro Business-Class
        LAMBDA_PE_A = LAMBDA_T_A * self.P_T_PE_A  # Tasso medio d'arrivo al centro Premium-Economy
        LAMBDA_ECO_A = LAMBDA_T_A * self.P_T_E_A  # Tasso medio d'arrivo al centro Economy
        LAMBDA_BM_A = LAMBDA_T_A * self.P_T_OB_A  # Tasso medio d'arrivo per Bagaglio a Mano

        LAMBDA_2_A = LAMBDA_BM_A + LAMBDA_ECO_A + LAMBDA_PE_A

        # -------------------- Check-In Low-Cost --------------
        LAMBDA_LC_A = LAMBDA_A * self.P_L_A
        LAMBDA_FP_A = (LAMBDA_LC_A * self.P_L_NOB_A) * self.P_L_FP_A  # Tasso medio d'arrivo al centro Flexi-Plus
        LAMBDA_SBD_A = (LAMBDA_LC_A * self.P_L_NOB_A) * self.P_L_SB_e_D_A  # Tasso medio d'arrivo al centro Self Bag and Drop
        LAMBDA_BD_A = (LAMBDA_LC_A * self.P_L_NOB_A) * self.P_L_B_e_D_A  # Tasso medio d'arrivo al centro Bag and Drop
        LAMBDA_BM_LC_A = LAMBDA_LC_A * self.P_L_OB_A  # Tasso medio d'arrivo per Bagaglio a Mano

        LAMBDA_BM_TOT_A = LAMBDA_BM_A + LAMBDA_BM_LC_A

        LAMBDA_3_A_NI = LAMBDA_SBD_A + LAMBDA_BD_A + LAMBDA_BM_LC_A
        LAMBDA_3_A_I = LAMBDA_BM_LC_A

        LAMBDA_4_A = LAMBDA_2_A + LAMBDA_3_A_NI
        LAMBDA_4_A_I = LAMBDA_2_A + LAMBDA_3_A_I
        #Lambda4A_I = 0.022326012
        ################ ZONA CHECK IN B  ###################
        # -------------------- Check-In tradizionale --------------
        LAMBDA_T_B = LAMBDA_B * self.P_T_B
        LAMBDA_BC_B = LAMBDA_T_B * self.P_T_B_B  # Tasso medio d'arrivo al centro Business-Class
        LAMBDA_PE_B = LAMBDA_T_B * self.P_T_PE_B  # Tasso medio d'arrivo al centro Premium-Economy
        LAMBDA_ECO_B = LAMBDA_T_B * self.P_T_E_B  # Tasso medio d'arrivo al centro Economy
        LAMBDA_BM_B = LAMBDA_T_B * self.P_T_OB_B  # Tasso medio d'arrivo per Bagaglio a Mano

        LAMBDA_2_B = LAMBDA_BM_B + LAMBDA_ECO_B + LAMBDA_PE_B

        # -------------------- Check-In Low-Cost --------------
        LAMBDA_LC_B = LAMBDA_B * self.P_L_B
        LAMBDA_C_B = (LAMBDA_LC_B * self.P_L_NOB_B) * self.P_L_C_B  # Tasso medio d'arrivo al centro Flexi-Plus
        LAMBDA_BD_B = (LAMBDA_LC_B * self.P_L_NOB_B) * self.P_L_BD_B  # Tasso medio d'arrivo al centro Self Bag and Drop
        LAMBDA_BM_LC_B = LAMBDA_LC_B * self.P_L_OB_B  # Tasso medio d'arrivo per Bagaglio a Mano

        LAMBDA_BM_TOT_B = LAMBDA_BM_B + LAMBDA_BM_LC_B


        LAMBDA_3_B_NI = LAMBDA_BD_B + LAMBDA_BM_LC_B + LAMBDA_C_B
        LAMBDA_3_B_I = LAMBDA_BM_LC_B + LAMBDA_C_B
        LAMBDA_4_B = LAMBDA_2_B + LAMBDA_3_B_NI
        LAMBDA_4_B_I = LAMBDA_2_B + LAMBDA_3_B_I

        ################ ZONA CHECK IN C  ###################
        # -------------------- Check-In tradizionale --------------
        LAMBDA_T_C = LAMBDA_C * self.P_T_C
        LAMBDA_BC_C = LAMBDA_T_C * self.P_T_B_C  # Tasso medio d'arrivo al centro Business-Class
        LAMBDA_PE_C = LAMBDA_T_C * self.P_T_PE_C  # Tasso medio d'arrivo al centro Premium-Economy
        LAMBDA_ECO_C = LAMBDA_T_C * self.P_T_E_C  # Tasso medio d'arrivo al centro Economy
        LAMBDA_BM_C = LAMBDA_T_C * self.P_T_OB_C  # Tasso medio d'arrivo per Bagaglio a Mano

        LAMBDA_2_C = LAMBDA_BM_C + LAMBDA_ECO_C + LAMBDA_PE_C

        # -------------------- Check-In Low-Cost --------------
        LAMBDA_LC_C = LAMBDA_C * self.P_L_C
        LAMBDA_C_C = (LAMBDA_LC_C * self.P_L_NOB_C) * self.P_L_C_C  # Tasso medio d'arrivo al centro Flexi-Plus
        LAMBDA_BD_C = (LAMBDA_LC_C * self.P_L_NOB_C) * self.P_L_BD_C  # Tasso medio d'arrivo al centro Self Bag and Drop
        LAMBDA_BM_LC_C = LAMBDA_LC_C * self.P_L_OB_C  # Tasso medio d'arrivo per Bagaglio a Mano

        LAMBDA_BM_TOT_C = LAMBDA_BM_C + LAMBDA_BM_LC_C

        LAMBDA_3_C = LAMBDA_BD_C + LAMBDA_BM_LC_C + LAMBDA_C_C
        LAMBDA_3_C_I = LAMBDA_BM_LC_C + LAMBDA_C_C

        LAMBDA_4_C = LAMBDA_2_C + LAMBDA_3_C
        LAMBDA_4_C_I = LAMBDA_2_C + LAMBDA_3_C_I

        # -------------------- Ingresso Area di Sicurezza -------------
        LAMBDA_4 = (LAMBDA_4_A + LAMBDA_4_B + LAMBDA_4_C)
        LAMBDA_4_I = (LAMBDA_4_A_I + LAMBDA_4_B_I + LAMBDA_4_C_I)

        LAMBDA_BM_TOT = LAMBDA_BM_TOT_C + LAMBDA_BM_TOT_A + LAMBDA_BM_TOT_B

        # -------------------- Fast-Track --------------------------------
        # Valido sia per l'ingresso al tornello che per l'ingresso all'aera di sicurezza riservato all'area Fast-Track
        LAMBDA_6_NI = (LAMBDA_4 * self.P_FT_NI) + LAMBDA_BC_A + LAMBDA_FP_A + LAMBDA_BC_B + LAMBDA_BC_C
        LAMBDA_6_I = (LAMBDA_4_I * self.P_FT_NI) + LAMBDA_BC_A + LAMBDA_FP_A + LAMBDA_BC_B + LAMBDA_BC_C

        # -------------------- Normale --------------------------------
        # Valido sia per l'ingresso al tornello che per l'ingresso all'aera di sicurezza riservato all'area Normale
        LAMBDA_7_NI = (LAMBDA_4 * (1 - self.P_FT_NI))
        LAMBDA_7_I = (LAMBDA_4_I * (1 - self.P_FT_NI))

        LAMBDA_8 = (0.25 * LAMBDA_7_I) + LAMBDA_BD_A + LAMBDA_BD_B + LAMBDA_BD_C + LAMBDA_SBD_A


        if model_type == "no_improved":

            self.lambdas = {
                        "business_a": LAMBDA_BC_A,
                        "premium_economy_a": LAMBDA_PE_A,
                        "economy_a": LAMBDA_ECO_A,
                        "flexi_plus_a": LAMBDA_FP_A,
                        "self_bd_a": LAMBDA_SBD_A,
                        "bd_a": LAMBDA_BD_A,

                        "business_b": LAMBDA_BC_B,
                        "premium_economy_b": LAMBDA_PE_B,
                        "economy_b": LAMBDA_ECO_B,
                        "check_in_b": LAMBDA_C_B,
                        "bd_b": LAMBDA_BD_B,

                        "business_c": LAMBDA_BC_C,
                        "premium_economy_c": LAMBDA_PE_C,
                        "economy_c": LAMBDA_ECO_C,
                        "check_in_c": LAMBDA_C_C,
                        "bd_c": LAMBDA_BD_C,

                        "fast_track_turnstile": LAMBDA_6_NI,
                        "turnstile_area": LAMBDA_BM_TOT,
                        "security_area": LAMBDA_7_NI,
                        "fast_track_security_area": LAMBDA_6_NI,
                    }
        else :
            self.lambdas = {
                "business_a": LAMBDA_BC_A,
                "premium_economy_a": LAMBDA_PE_A,
                "economy_a": LAMBDA_ECO_A,
                "flexi_plus_a": LAMBDA_FP_A,
                "self_bd_a": LAMBDA_SBD_A,
                "bd_a": LAMBDA_BD_A,

                "business_b": LAMBDA_BC_B,
                "premium_economy_b": LAMBDA_PE_B,
                "economy_b": LAMBDA_ECO_B,
                "check_in_b": LAMBDA_C_B,
                "bd_b": LAMBDA_BD_B,

                "business_c": LAMBDA_BC_C,
                "premium_economy_c": LAMBDA_PE_C,
                "economy_c": LAMBDA_ECO_C,
                "check_in_c": LAMBDA_C_C,
                "bd_c": LAMBDA_BD_C,

                "fast_track_turnstile": LAMBDA_6_I,
                "turnstile_area": LAMBDA_BM_TOT,
                "security_area": LAMBDA_7_I * 0.75,
                "fast_track_security_area": LAMBDA_6_I,
                "fast_security_area": LAMBDA_8 ,
            }