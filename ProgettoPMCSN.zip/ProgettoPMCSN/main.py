import os
from libs.rng import *
import pandas as pd
from simulation import AirportSimulation
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from utils.welfordCalculator import *
from utils.confidence_interval_calculator import *

# Parametri della simulazione
seed_used = []  # Lista dei seed utilizzati per ogni replica della simulazione (Per ripetibilità)

# Scelte disponibili: "improved", per il modello migliorativo e "no_improved" per il modello originale senza miglioramento
MODEL_TYPE = "improved"

# ---------------- INFINITE HORIZON SIMULATION ----------------
INFINITE_HORIZON = False
BATCH_DIM =  34990                          # Campionamento ogni 16384 job (b)
BATCH_NUM =  64                           #Numero di campionamenti da eseguire (k)
INFINITE_HORIZON_TIME = BATCH_DIM * BATCH_NUM       # Lunghezza del campione

# ---------------- FINITE HORIZON SIMULATION ----------------
FINITE_HORIZON =       True
FINITE_HORIZON_TIME =  3600.0 * 24     # una giornata completa all'aeroporto --> 00:00 - 23:59
REPLICATION_NUM =      64              # numero di repliche eseguite
SAMPLING_RATE =        600             # Tempo di campionamento per le statistiche


def print_confidence_interval(mean, w):
    print(f"Mean is {mean}, confidence interval 95% is [{mean-w} -- {mean+w}]")

def show_confidence_intervals(mean_samples_check_in, mean_samples_sec, percentiles_samples_check_in, percentiles_samples_security):
    _, waiting_times_check_mean, waiting_times_check_dev = compute_metrics_welford(mean_samples_check_in)
    _, waiting_times_sec_mean, waiting_times_sec_dev = compute_metrics_welford(mean_samples_sec)

    print(f"Printing confidence interval for average waiting time in check in area...")
    w_mean_check = compute_confidence_interval(waiting_times_check_dev, len(mean_samples_check_in))
    print_confidence_interval(waiting_times_check_mean, w_mean_check)

    print(f"Printing confidence interval for average waiting time in security area...")
    w_mean_sec = compute_confidence_interval(waiting_times_sec_dev, len(mean_samples_sec))
    print_confidence_interval(waiting_times_sec_mean, w_mean_sec)

    _, percentile_mean_check_in, percentile_dev_check_in = compute_metrics_welford(percentiles_samples_check_in)
    _, percentile_mean_sec, percentile_dev_sec = compute_metrics_welford(percentiles_samples_security)

    print(f"Printing confidence interval for 90° percentile of waiting time in check in area...")
    w_mean_check = compute_confidence_interval(percentile_dev_check_in, len(percentiles_samples_check_in))
    print_confidence_interval(percentile_mean_check_in, w_mean_check)

    print(f"Printing confidence interval for 90° percentile of waiting time in security area...")
    w_mean_sec = compute_confidence_interval(percentile_dev_sec, len(percentiles_samples_security))
    print_confidence_interval(percentile_mean_sec, w_mean_sec)

def analyze_and_plot_qos(data, mean_val, std_val, ci_low, ci_high, label, target_qos_sec, output_prefix, percOrWait):
    output_dir = "plots_qos2"
    os.makedirs(output_dir, exist_ok=True)
    data = np.array(data)
    n = len(data)

    # Violazioni rispetto alla soglia
    violations = np.sum(data > target_qos_sec)
    prob_violation = violations / n * 100

    # === Report ===
    if percOrWait == "90° percentile":
        print(f"\n=== Report affidabilità QoS - {label} ===")
        print(f"Soglia QoS: {target_qos_sec:.2f} secondi ({target_qos_sec / 60:.2f} min)")
        print(f"Media dei 90° percentile: {mean_val:.2f} s")
        print(f"Deviazione standard: {std_val:.2f} s")
        print(f"Intervallo di confidenza 95% media: [{ci_low:.2f}, {ci_high:.2f}] s")
        print(f"Numero di repliche sopra soglia: {violations} / {n}")
        print(f"Probabilità stimata di violazione: {prob_violation:.2f} %")

    sns.set_theme(style="whitegrid")

    # Valori per replica
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, n + 1), data, "o-", color="skyblue", label="Repliche")
    plt.axhline(mean_val, color="darkblue", linestyle="-", label="Media")
    plt.axhline(ci_low, color="gray", linestyle="--", label="IC 95%")
    plt.axhline(ci_high, color="gray", linestyle="--")

    # Riempimento tra i limiti dell'intervallo di confidenza
    plt.fill_between(
        range(1, n + 1),
        ci_low,
        ci_high,
        color="gray",
        alpha=0.2,  # trasparenza
        label="Intervallo di confidenza"
    )

    if percOrWait == "90° percentile":
        plt.axhline(target_qos_sec, color="red", linestyle="--", label="Soglia QoS")

    plt.title(f"{percOrWait} per replica con media e IC - {label}")
    plt.xlabel("Replica")
    plt.ylabel("Tempo (s)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"repliche_{percOrWait}_{output_prefix}.png"), dpi=300)
    plt.close()

def analyze_percentiles(all_seeds_metrics):
    all_pools = set()
    for df in all_seeds_metrics.values():
        all_pools.update(df["pool_name"].unique())

    for pool in all_pools:
        if pool == "daily_percentile_90_wait":

            for column in ["security","check_in"]:
                mean_df_list = []

                # --- PRIMO GRAFICO: curve dei singoli seed ---
                plt.figure(figsize=(12, 6))
                for seed, df in all_seeds_metrics.items():
                    df_pool = df[df["pool_name"] == pool]
                    if df_pool.empty:
                        continue
                    df_grouped = df_pool.groupby("time")[column].mean().reset_index()
                    mean_df_list.append(df_grouped.rename(columns={column: f"{column}_{seed}"}))
                    plt.plot(df_grouped["time"], df_grouped[column], alpha=0.6, label=f"Seed {seed}")

                # Linee verticali per fasce orarie
                time_slots = [
                    (0, 359 * 60 + 59, "night"),
                    (360 * 60, 539 * 60 + 59, "morning"),
                    (540 * 60, 719 * 60 + 59, "late_morning"),
                    (720 * 60, 899 * 60 + 59, "early_afternoon"),
                    (900 * 60, 1139 * 60 + 59, "late_afternoon"),
                    (1140 * 60, 1319 * 60 + 59, "evening"),
                    (1320 * 60, 1440 * 60 + 59, "late_evening"),
                ]
                ymin, ymax = plt.ylim()
                for start, _, label in time_slots:
                    plt.axvline(x=start, color="green", linestyle="--", linewidth=1.5)
                    plt.text(start, ymin - (ymax * 0.05), label, rotation=90,
                             verticalalignment="top", horizontalalignment="center",
                             fontsize=9, color="green")

                plt.xlabel("Tempo (secondi)")
                plt.ylabel("90th percentile tempo di attesa")
                plt.title(f"Andamento 90° percentile per {column} (curve singoli seed)")
                plt.grid(True)
                plt.tight_layout()

                global_dir = f"90th_percentile_{column}_waits{MODEL_TYPE}"
                os.makedirs(global_dir, exist_ok=True)
                plt.savefig(os.path.join(global_dir, f"{pool}_{column}_seeds.png"))
                plt.close()

                # --- SECONDO GRAFICO: curva media ---
                if mean_df_list:
                    df_merged = mean_df_list[0]
                    for df_other in mean_df_list[1:]:
                        df_merged = pd.merge(df_merged, df_other, on="time", how="outer")

                    mean_col = df_merged.filter(like=column).mean(axis=1)

                    plt.figure(figsize=(12, 6))
                    plt.plot(df_merged["time"], mean_col, color="black", linewidth=2.5, label="Media dei seed")

                    ymin, ymax = plt.ylim()
                    for start, _, label in time_slots:
                        plt.axvline(x=start, color="green", linestyle="--", linewidth=1.5)
                        plt.text(start, ymin - (ymax * 0.05), label, rotation=90,
                                 verticalalignment="top", horizontalalignment="center",
                                 fontsize=9, color="green")

                    plt.xlabel("Tempo (secondi)")
                    plt.ylabel("Media 90th percentile tempo di attesa")
                    plt.title(f"Andamento medio 90° percentile per {column} (media dei seed)")
                    plt.legend()
                    plt.grid(True)
                    plt.tight_layout()

                    plt.savefig(os.path.join(global_dir, f"{pool}_{column}_mean.png"))
                    plt.close()

def analyze_and_plot_transient(all_seeds_metrics):
    metrics = ["avg_utilization", "avg_waiting_time", "avg_response_time", "avg_queue_population"]

    all_pools = set()
    for df in all_seeds_metrics.values():
        all_pools.update(df["pool_name"].unique())

    for pool in all_pools:
        if pool == "daily_percentile_90_wait":
            continue
        else:
            for metric in metrics:
                plt.figure(figsize=(12, 6))
                for seed, df in all_seeds_metrics.items():
                    df_pool = df[df["pool_name"] == pool]
                    if df_pool.empty:
                        continue
                    df_grouped = df_pool.groupby("time")[metric].mean().reset_index()
                    plt.plot(df_grouped["time"], df_grouped[metric], label=f"Seed {seed}")

                plt.xlabel("Tempo")
                plt.ylabel(metric)
                plt.title(f"Andamento di {metric} per {pool} (confronto seed)")
                plt.legend()
                plt.grid(True)
                plt.tight_layout()

                global_dir = "global_metrics_" + MODEL_TYPE
                os.makedirs(global_dir, exist_ok=True)
                plt.savefig(os.path.join(global_dir, f"{pool}_{metric}.png"))
                plt.close()


def finite_horizon_run():
    mean_samples_check_in = []
    mean_samples_sec = []

    percentiles_samples_check_in =  []
    percentiles_samples_security =  []

    total_percentiles_waits_security = []
    total_percentiles_waits_check_in = []
    all_seeds_metrics = {}  # per memorizzare df di ogni seed

    current_seed = 123456789
    seed_used.append(current_seed)
    plant_seeds(current_seed)  # imposta il seed per la replica corrente

    for idx in range(REPLICATION_NUM):
        print(f"\nAvvio replica {idx + 1}/{REPLICATION_NUM} - Seed: {current_seed}")

        sim = AirportSimulation(
            end_time=FINITE_HORIZON_TIME,
            sampling_rate=SAMPLING_RATE,
            type_simulation="finite",
            model_type=MODEL_TYPE,
        )
        replica_metrics = sim.run()
        mean_samples_check_in.append(replica_metrics["replica_mean_check"])
        mean_samples_sec.append(replica_metrics["replica_mean_Security"])

        percentiles_samples_check_in.append(replica_metrics["daily_percentile_90_wait"][-1]["check_in"])
        percentiles_samples_security.append(replica_metrics["daily_percentile_90_wait"][-1]["security"])

        for el in replica_metrics["daily_percentile_90_wait"]:
            total_percentiles_waits_security.append(el["security"])
            total_percentiles_waits_check_in.append(el["check_in"])

        # -------------------- Converti in DataFrame --------------------
        all_data = []
        for key in replica_metrics.keys():
            if isinstance(replica_metrics[key], list):
                for snap in replica_metrics[key]:
                    snap["pool_name"] = key
                    all_data.append(snap)
            elif isinstance(replica_metrics[key], dict):  # turnstiles
                for server_name, server_snaps in replica_metrics[key].items():
                    for snap in server_snaps:
                        snap["pool_name"] = f"{key}_{server_name}"
                        all_data.append(snap)

        df = pd.DataFrame(all_data).sort_values(["pool_name", "time"])
        all_seeds_metrics[current_seed] = df
        current_seed = get_seed()
        seed_used.append(current_seed)

    # ------------------------------------------------
    # Intervalli di confidenza
    # ------------------------------------------------
    show_confidence_intervals(mean_samples_check_in, mean_samples_sec, percentiles_samples_check_in,percentiles_samples_security)

    # ------------------------------------------------
    # Grafici Percentili
    # ------------------------------------------------
    analyze_percentiles(all_seeds_metrics)

    # ------------------------------------------------
    # Grafici transitorio
    # ------------------------------------------------
    analyze_and_plot_transient(all_seeds_metrics)

    # ------------------------------------------------
    # Analisi Qos per check-in
    # ------------------------------------------------

    _, percentile_mean_check_in, percentile_dev_check_in = compute_metrics_welford(percentiles_samples_check_in)
    _, percentile_mean_sec, percentile_dev_sec = compute_metrics_welford(percentiles_samples_security)

    w_mean_check = compute_confidence_interval(percentile_dev_check_in, len(percentiles_samples_check_in))
    w_mean_sec = compute_confidence_interval(percentile_dev_sec, len(percentiles_samples_security))

    analyze_and_plot_qos(
        data=percentiles_samples_check_in,
        mean_val = percentile_mean_check_in,
        std_val = percentile_dev_check_in,
        ci_low = percentile_mean_check_in - w_mean_check,
        ci_high= percentile_mean_check_in + w_mean_check,
        label="Check-in",
        target_qos_sec=15.55 * 60,
        output_prefix="check_in",
        percOrWait = "90° percentile"
    )

    # ------------------------------------------------
    # Analisi QoS per security
    # ------------------------------------------------
    analyze_and_plot_qos(
        data=percentiles_samples_security,
        mean_val = percentile_mean_sec,
        std_val = percentile_dev_sec,
        ci_low = percentile_mean_sec - w_mean_sec,
        ci_high= percentile_mean_sec + w_mean_sec,
        label="Security",
        target_qos_sec=5.40 * 60,
        output_prefix="security",
        percOrWait="90° percentile"
    )

    _, waiting_times_check_mean, waiting_times_check_dev = compute_metrics_welford(mean_samples_check_in)
    _, waiting_times_sec_mean, waiting_times_sec_dev = compute_metrics_welford(mean_samples_sec)

    w_mean_check = compute_confidence_interval(waiting_times_check_dev, len(mean_samples_check_in))
    w_mean_sec = compute_confidence_interval(waiting_times_sec_dev, len(mean_samples_sec))


    analyze_and_plot_qos(
        data=mean_samples_check_in,
        mean_val=waiting_times_check_mean,
        std_val=waiting_times_check_dev,
        ci_low=waiting_times_check_mean - w_mean_check,
        ci_high=waiting_times_check_mean + w_mean_check,
        label="Check-in",
        target_qos_sec=15.55 * 60,
        output_prefix="check_in",
        percOrWait="Media tempi attesa"
    )


    analyze_and_plot_qos(
        data=mean_samples_sec,
        mean_val = waiting_times_sec_mean,
        std_val = waiting_times_sec_dev,
        ci_low = waiting_times_sec_mean - w_mean_sec,
        ci_high= waiting_times_sec_mean + w_mean_sec,
        label="Security",
        target_qos_sec=5.40 * 60,
        output_prefix="security",
        percOrWait="Media tempi attesa"
    )


def infinite_horizon_run():
    # Inizializza il seed
    current_seed = 123456789
    seed_used.append(current_seed)
    plant_seeds(current_seed)

    # Avvia simulazione
    sim = AirportSimulation(
        end_time=float('inf'),
        sampling_rate=BATCH_DIM,
        type_simulation="infinite",
        batch_num=BATCH_NUM,
        model_type = MODEL_TYPE,
    )
    metrics = sim.run()

    # -------------------- Converti in DataFrame unico --------------------
    all_data = []
    for key in metrics.keys():
        if isinstance(metrics[key], list):
            for snap in metrics[key]:
                snap["pool_name"] = key
                all_data.append(snap)
        else:  # caso turnstiles (dizionario per server)
            for server_name, server_snaps in metrics[key].items():
                for snap in server_snaps:
                    snap["pool_name"] = f"{key}_{server_name}"
                    all_data.append(snap)

if __name__ == '__main__':
    if INFINITE_HORIZON:
        infinite_horizon_run()

    elif FINITE_HORIZON:
        finite_horizon_run()

    else:
        raise ValueError("Errore: Nessun orizzonte di simulazione selezionato")
