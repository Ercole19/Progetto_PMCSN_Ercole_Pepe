from collections import deque
from abc import ABC, abstractmethod

from entity.Server import ClassicCheckInServer
from libs.rng import select_stream, random


class ServerPool(ABC):
    def __init__(self, servers, debug=True):
        self.servers = servers
        self.debug = debug

    @abstractmethod
    def reset_pool(self):
        pass

    @abstractmethod
    def assign_event(self, event, event_list, times, op_index):
        pass

    @abstractmethod
    def start_next(self, *args, **kwargs):
        pass

    @abstractmethod
    def total_in_system(self):
        pass

    def avg_utilization(self, current_time):
        return sum(s.utilization(current_time) for s in self.servers) / len(self.servers)


class MultiServerSingleQueuePool(ServerPool):
    def __init__(self, servers):
        super().__init__(servers)
        self.queue = deque()
        self.queues = []
        self.total_busy_time = 0.0
        self.last_event_time = 0.0
        self.state = 0
        self.added = False
        self.last_time = -1

    def reset_pool(self):
        self.queue.clear()
        self.queues = []
        self.total_busy_time = 0.0
        self.last_event_time = 0.0
        self.state = 0

        for s in self.servers:
            s.reset_server()

    def update_busy_time(self, current_time):
        """Aggiorna il busy time fino al current_time"""
        if self.state == 1:
            self.total_busy_time += current_time - self.last_event_time
        self.last_event_time = current_time

    def assign_event(self, event, event_list, times, op_index):
        # Cerchiamo un server libero
        free_server = next((s for s in self.servers if s.state == 0), None)

        # --- ASSEGNAZIONE O CODA ---
        if free_server:
            # Assegnazione standard
            event.arrival_time = times.next
            self.queues.append(0)  # Monitoraggio code
            self.update_busy_time(times.next)
            self.state = 1
            free_server.start_service(event, event_list, times)
            free_server.arrivals.append(times.next)
            free_server.num_in_system += 1
        else:
            # Tutti occupati: controlliamo se serve SCALING UP
            if self.servers and op_index in ["economy_a", "economy_b", "economy_c"]:
                if len(self.queue) >= 15 and not self.added:
                    new_server = ClassicCheckInServer(f"{op_index}_extra", "finite")
                    self.servers.append(new_server)
                    self.added = True

                    # Il nuovo server prende IMMEDIATAMENTE un evento dalla coda (FIFO)
                    # Nota: usiamo popleft() perché è una deque
                    if self.queue:
                        waiting_event = self.queue.popleft()
                        new_server.start_service(waiting_event, event_list, times)
                        new_server.arrivals.append(times.next)
                        new_server.num_in_system += 1

            # L'evento corrente entra comunque in coda (perché tutti erano occupati
            # e se abbiamo aggiunto un server, lui ha preso qualcuno che aspettava da prima)
            event.arrival_time = times.next
            self.queue.append(event)

    def start_next(self, event_list, times):
        while self.queue:
            free_server = next((s for s in self.servers if s.state == 0), None)
            if not free_server:
                break
            next_event = self.queue.popleft()


            queue_time = times.next - next_event.arrival_time
            self.queues.append(queue_time)
            self.update_busy_time(times.next)
            self.state = 1

            free_server.start_service(next_event, event_list, times, queue_time)
            next_event.event_time = times.next
            free_server.arrivals.append(next_event.event_time)
            free_server.num_in_system += 1
    def total_in_system(self):
        return sum(s.num_in_system for s in self.servers) + len(self.queue)



class MultiServerMultiQueuesPool(ServerPool):
    def __init__(self, servers):
        super().__init__(servers)

    def reset_pool(self):
        for s in self.servers:
            s.reset_server()
            s.queue.clear()

    def assign_event(self, event, event_list, times, op_index):
        for s in self.servers:
            if s.state == 0:
                event.arrival_time = times.next
                s.start_service(event, event_list, times)
                s.arrivals.append(times.next)
                s.num_in_system += 1
                return

        chosen = min(self.servers, key=lambda s: len(s.queue))
        event.arrival_time = times.next
        chosen.queue.append(event)


    def assign_event_infinite(self, event, event_list, times):
        # Assegnazione sempre uniforme tra tutte le server (indipendente dallo stato)
        select_stream(88)
        r = random()
        idx = int(r * len(self.servers))
        chosen = self.servers[idx]

        event.arrival_time = times.next

        # se server scelto è libero, partirà subito; altrimenti finirà in coda
        if chosen.state == 0:
            chosen.start_service(event, event_list, times)
            chosen.arrivals.append(times.next)
            chosen.num_in_system += 1
        else:
            chosen.queue.append(event)


    def start_next(self, server, event_list, times):
        if server.queue:
            next_event = server.queue.popleft()
            queue_time = times.next - next_event.arrival_time
            server.start_service(next_event, event_list, times, queue_time)
            next_event.event_time = times.next
            server.arrivals.append(next_event.event_time)
            server.num_in_system += 1

    def total_in_system(self):
        return sum(s.num_in_system + len(s.queue) for s in self.servers)

    def avg_utilization(self, current_time):
        return sum(s.utilization(current_time) for s in self.servers) / len(self.servers)