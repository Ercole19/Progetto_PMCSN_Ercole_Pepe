import heapq
from abc import ABC, abstractmethod
from distributions.distributions import exponential
from entity.Entity import *
from libs.rng import select_stream, random
from utils.utils import truncate_lognormal
from collections import deque


class Server(ABC):
    def __init__(self, name, debug=True):
        self.start_time = 0
        self.name = name
        self.state = 0  # 0=free, 1=busy
        self.arrivals = []
        self.completed = []
        self.queue_waits = []
        self.response_times = []
        self.num_in_system = 0
        self.total_busy_time = 0.0
        self.debug = debug
        self.last_event_time = 0.0

    def reset_server(self):
        self.state = 0
        self.arrivals = []
        self.completed = []
        self.num_in_system = 0
        self.total_busy_time = 0.0
        self.start_time = 0.0
        self.queue_waits = []
        self.response_times = []
        self.last_event_time = 0.0

    def update_busy_time(self, current_time):
        """Aggiorna il busy time fino al current_time"""
        if self.state == 1:
            self.total_busy_time += current_time - self.last_event_time
        self.last_event_time = current_time

    def start_service(self, event, event_list, times, queue_time=0):
        # aggiorna busy time prima di cambiare stato
        self.update_busy_time(times.next)
        self.state = 1

        service_time = max(1e-3, self.get_service())
        self.start_time = times.next
        event.start_service_time = self.start_time
        event.service_time = service_time
        event.queue_time = queue_time
        self.queue_waits.append(queue_time)

        heapq.heappush(event_list, (self.start_time + service_time, "C", self, event))

    def handle_departure(self, event, event_list, model_type, isMultiServerMultiQueues, pool=None, times=None):
        completion_time = times.next

        # aggiorna busy time prima di liberare il server
        self.update_busy_time(completion_time)

        self.completed.append(completion_time)
        self.num_in_system -= 1
        self.state = 0

        self.response_times.append(event.queue_time + event.service_time)

        if isMultiServerMultiQueues:
            pool.start_next(self, event_list, times)
        else:
            pool.start_next(event_list, times)

        next_center_name = getattr(event, "next_center", None)
        op_index = getattr(event, "op_index", None)
        if next_center_name is not None:
            new_event = Event(completion_time, "A", next_center_name)
            #new_event.nums_hops = event.nums_hops + 1
            if model_type == "improved":
                if op_index in ["self_bd_a", "bd_a", "bd_b", "bd_c"]:
                    new_event.check_in_done = True
                elif op_index in ["premium_economy_a", "economy_a", "turnstile_area", "premium_economy_b", "economy_b", "check_in_b", "economy_c", "premium_economy_c", "check_in_c"]:
                    select_stream(125)
                    r = random()
                    if r <= 0.25:
                        new_event.check_in_done = True
            heapq.heappush(event_list, (new_event.event_time, "A", new_event))

    def utilization(self, current_time):
        self.update_busy_time(current_time)
        return self.total_busy_time / max(1e-9, current_time)


    def avg_wait_time(self):
        queue_total = sum(qt for qt in self.queue_waits)
        if len(self.queue_waits) > 0:
            return queue_total / len(self.queue_waits)
        else : return 0

    def avg_response_time(self):
        resp_total = sum(qt for qt in self.response_times)
        if len(self.response_times) > 0:
            return resp_total / len(self.response_times)
        else:
            return 0

    @abstractmethod
    def get_service(self):
        pass


class ClassicCheckInServer(Server):
    def __init__(self, name, type_simulation):
        super().__init__(name)
        self.type_simulation = type_simulation
        self.queue = deque()
    def get_service(self):
        if self.type_simulation == "finite":
            return truncate_lognormal(5.15195, 0.05, 60, 200)
        else : return exponential(180)

class BagDropCheckInServer(Server):
    def __init__(self, name, type_simulation):
        super().__init__(name)
        self.type_simulation = type_simulation
        self.queue = deque()
    def get_service(self):
        if self.type_simulation == "finite":
            return truncate_lognormal(4.5, 0.15, 40, 180)
        else: return exponential(90)

class TurnstileServer(Server):
    def __init__(self, name, type_simulation):
        super().__init__(name)
        self.queue = deque()
        self.type_simulation = type_simulation
    def get_service(self):
        if self.type_simulation == "finite":
            return 10
        else: return exponential(10)

class SecurityCheckServer(Server):
    def __init__(self, name, type_simulation):
        super().__init__(name)
        self.queue = deque()
        self.type_simulation = type_simulation
    def get_service(self):
        if self.type_simulation == "finite":
            return truncate_lognormal(4.4179, 0.042, 40, 240)
        else : return exponential(60)

class FastSecurityCheckServer(Server):
    def __init__(self, name, type_simulation):
        super().__init__(name)
        self.queue = deque()
        self.type_simulation = type_simulation
    def get_service(self):
        if self.type_simulation == "finite":
            return truncate_lognormal(3.6851, 0.0872, 30, 60)
        else : return exponential(40)
