import numpy as np

def compute_confidence_interval(dev, n):
    t_inf = 1.960

    numerator = t_inf * dev
    denominator = np.sqrt(n-1)

    w = numerator / denominator

    return w


def compute_tollerance_interval(mean, dev):
    k = 1.65
    print(f"Intervallo di tolleranza al 90% con 95% di confidenza è: {mean + k*dev}")