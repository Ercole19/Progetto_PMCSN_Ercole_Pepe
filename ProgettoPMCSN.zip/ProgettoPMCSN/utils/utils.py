import numpy as np
from scipy.stats import lognorm

from libs.rvgs import *
from libs.rvms import *

def truncate_lognormal(mu, sigma, inf, sup):
    """
    Tronca la distribuzione lognormale tra inf e sup.
    Utilizza le funzioni cdfLognormal e idfLognormal.
    """
    # Check input validity
    if inf <= 0:
        raise ValueError("Il limite inferiore deve essere > 0")
    if sup <= inf:
        raise ValueError("Il limite superiore deve essere maggiore del limite inferiore")

    alpha = cdfLognormal(mu, sigma, inf)
    beta = cdfLognormal(mu, sigma, sup)

    if alpha >= beta:
        return sup if beta > 0.999999 else inf

    epsilon = 1e-12
    u = Uniform(alpha + epsilon, beta - epsilon)

    return idfLognormal(mu, sigma, u)  # passare max_iter a idfLognormal


def truncate_normal(mu, sigma, inf, sup):
    """
    Tronca la distribuzione lognormale tra inf e sup.
    Utilizza le funzioni cdfLognormal e idfLognormal.
    """
    # Check input validity
    if inf <= 0:
        raise ValueError("Il limite inferiore deve essere > 0")
    if sup <= inf:
        raise ValueError("Il limite superiore deve essere maggiore del limite inferiore")

    alpha = cdfNormal(mu, sigma, inf)
    beta = cdfNormal(mu, sigma, sup)

    if alpha >= beta:
        return sup if beta > 0.999999 else inf

    epsilon = 1e-12
    u = Uniform(alpha + epsilon, beta - epsilon)

    return idfNormal(mu, sigma, u)  # passare max_iter a idfLognormal


