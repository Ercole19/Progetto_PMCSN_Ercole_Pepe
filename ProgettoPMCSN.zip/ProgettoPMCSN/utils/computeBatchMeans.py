import numpy as np
from scipy import stats
from tabulate import tabulate
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os




def confidence_interval(data, confidence=0.95):
    n = len(data)
    mean = np.mean(data)
    se = stats.sem(data)
    h = se * stats.t.ppf((1 + confidence) / 2., n - 1)
    return mean, mean - h, mean + h

def compute_batch_means_cis(metrics, center_name):
    metriche_da_controllare = [
        "avg_utilization",
        "avg_queue_population",
        "avg_response_time",
        "avg_waiting_time",
        "avg_system_population",
    ]

    # Aggregazione dei dati
    if isinstance(metrics, dict):
        aggregated_metrics = {}
        for key, metric_list in metrics.items():
            for m in metric_list:
                for metrica in metriche_da_controllare:
                    if metrica in m and m[metrica] is not None:
                        aggregated_metrics.setdefault(metrica, []).append(m[metrica])
        metrics_to_use = aggregated_metrics
    else:
        metrics_to_use = {metrica: [m[metrica] for m in metrics if metrica in m and m[metrica] is not None]
                          for metrica in metriche_da_controllare}

    # Preparazione tabella
    headers = ["Metrica", "Media", "IC 95%", "Ampiezza Intervallo"]
    table = []

    for metrica, valori in metrics_to_use.items():
        if len(valori) < 2:
            table.append([metrica, "N/A", "N/A", "N/A", "N/A"])
            continue

        media, ci_low, ci_high = confidence_interval(valori)
        ampiezza = ci_high - ci_low
        table.append([metrica, f"{media:.4f}", f"[{ci_low:.4f} - {ci_high:.4f}]", f"{ampiezza:.4f}"])

    print("\n--- Intervalli di Confidenza (95%) per le metriche ---\n")
    print(tabulate(table, headers=headers, tablefmt="grid"))
    plot_metrics_with_ci_area(metrics_to_use, center_name)   # <---- aggiunta qui

    return metrics_to_use  # così possiamo usarle per i plot



def plot_metrics_with_ci_area(metrics_to_use, centro_name):
    metriche_da_plottare = ["avg_waiting_time", "avg_queue_population"]
    n_metrics = len(metriche_da_plottare)

    # Altezza ridotta dei subplot
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))  # Altezza ridotta da 10 a 6
    axes = axes.flatten()

    for i, metrica in enumerate(metriche_da_plottare):
        valori = np.array(metrics_to_use[metrica])
        if len(valori) < 2:
            continue

        # Media cumulativa e intervallo di confidenza cumulativo
        cum_means = np.cumsum(valori) / (np.arange(len(valori)) + 1)
        ci_lows = []
        ci_highs = []
        for j in range(len(valori)):
            mean_j, ci_low_j, ci_high_j = confidence_interval(valori[:j+1])
            ci_lows.append(ci_low_j)
            ci_highs.append(ci_high_j)

        x = np.arange(1, len(valori)+1)
        ax = axes[i]
        ax.plot(x, cum_means, label="Media cumulativa", color="blue")
        ax.fill_between(x, ci_lows, ci_highs, color="blue", alpha=0.2, label="IC 95%")
        ax.set_title(metrica)
        ax.set_xlabel("Batch")
        ax.set_ylabel("Valore")
        ax.grid(True, linestyle='--', alpha=0.5)  # Griglia attivata
        ax.legend()

    plt.tight_layout()
    os.makedirs("plots", exist_ok=True)
    plt.savefig(f"plots/{centro_name}_metrics_cumulative_ci.png", dpi=300)
    plt.close()
