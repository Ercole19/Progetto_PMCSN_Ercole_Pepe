import numpy as np


def compute_metrics_welford(samples):
        n = 0
        mean = 0
        v = 0
        for sample in samples:
            n += 1
            d = sample - mean
            v = v + d*d * (n - 1) / n
            mean = mean + d / n
            
        s = np.sqrt(v / n)
        return n, mean, s




