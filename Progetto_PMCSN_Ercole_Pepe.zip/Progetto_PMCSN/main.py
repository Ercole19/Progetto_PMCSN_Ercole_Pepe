import os
from libs.rng import *
import pandas as pd
import numpy as np
from simulation import AirportSimulation
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt



# Parametri della simulazione
seed_used = []  # Lista dei seed utilizzati per ogni replica della simulazione (Per ripetibilità)

# Scelte disponibili: "full_improved", per il modello migliorativo completo; "semi_improved", per miglioramento medio e "no_improved" per il modello originale senza miglioramento
MODEL_TYPE = "full_improved"

# ---------------- INFINITE HORIZON SIMULATION ----------------
INFINITE_HORIZON = False
BATCH_DIM =  16384                           # Campionamento ogni 16384 job (b)
BATCH_NUM =  25                              # Numero di campionamenti da eseguire (k)
INFINITE_HORIZON_TIME = BATCH_DIM * BATCH_NUM       # Lunghezza del campione

# ---------------- FINITE HORIZON SIMULATION ----------------
FINITE_HORIZON =       True
FINITE_HORIZON_TIME =  3600.0 * 24     # una giornata completa all'aeroporto --> 00:00 - 23:59
REPLICATION_NUM =      28           # numero di repliche eseguite
SAMPLING_RATE =        600           # Tempo di campionamento per le statistiche


def finite_horizon_run():
    total_percentiles_waits_security = []
    total_percentiles_waits_check_in = []
    all_seeds_metrics = {}  # per memorizzare df di ogni seed

    if MODEL_TYPE in ["full_improved", "no_improved"]:
        current_seed = 123456789
    else:
        current_seed = 987654321
    seed_used.append(current_seed)

    for idx in range(REPLICATION_NUM):
        print(f"\nAvvio replica {idx + 1}/{REPLICATION_NUM} - Seed: {current_seed}")
        plant_seeds(seed_used[idx])  # imposta il seed per la replica corrente

        sim = AirportSimulation(
            end_time=FINITE_HORIZON_TIME,
            sampling_rate=SAMPLING_RATE,
            type_simulation="finite",
            model_type=MODEL_TYPE,
        )
        replica_metrics = sim.run()
        for el in replica_metrics["daily_percentile_90_wait"]:
            total_percentiles_waits_security.append(el["security"])
            total_percentiles_waits_check_in.append(el["check_in"])

        # -------------------- Stampa metriche finali --------------------
        total_in_system = 0
        for pool_name, snapshots in replica_metrics.items():
            if isinstance(snapshots, dict) and pool_name != "daily_percentile_90_wait":
                for server_name, server_snaps in snapshots.items():
                    if not server_snaps:
                        continue
                    last_snapshot = server_snaps[-1]
                    print(f"  Pool={server_name}")
                    print(f"    In System: {last_snapshot.get('in_system', 0)}")
                    print(f"    Queue Length: {last_snapshot.get('queue_length', 0)}")
                    print(f"    Utilization: {last_snapshot.get('avg_utilization', 0):.2f}")
                    print(f"    Avg Waiting Time: {last_snapshot.get('avg_waiting_time', 0):.2f}")
                    print(f"    Avg Response Time: {last_snapshot.get('avg_response_time', 0):.2f}")
                    total_in_system += last_snapshot.get('in_system', 0) + last_snapshot.get("queue_length", 0)

            elif isinstance(snapshots, list) and pool_name != "daily_percentile_90_wait":
                if not snapshots:
                    continue
                last_snapshot = snapshots[-1]
                print(f"  Pool={pool_name}")
                print(f"    In System: {last_snapshot.get('in_system', 0)}")
                print(f"    Queue Length: {last_snapshot.get('queue_length', 0)}")
                print(f"    Utilization: {last_snapshot.get('avg_utilization', 0):.2f}")
                print(f"    Avg Waiting Time: {last_snapshot.get('avg_waiting_time', 0):.2f}")
                print(f"    Avg Response Time: {last_snapshot.get('avg_response_time', 0):.2f}")
                total_in_system += last_snapshot.get('in_system', 0)

        if MODEL_TYPE != "no_improved":
            print(f"\n  Totale passeggeri completati: {replica_metrics['security_area']['security_0'][-1]['passengers_completed']}")
        else:
            print(f"\n  Totale passeggeri completati: {replica_metrics['security_area'][-1]['passengers_completed']}")
        print(f"  Totale passeggeri ancora in sistema: {total_in_system}")
        print("-" * 50)

        # -------------------- Converti in DataFrame --------------------
        all_data = []
        for key in replica_metrics.keys():
            if isinstance(replica_metrics[key], list):
                for snap in replica_metrics[key]:
                    snap["pool_name"] = key
                    all_data.append(snap)
            else:  # turnstiles
                for server_name, server_snaps in replica_metrics[key].items():
                    for snap in server_snaps:
                        snap["pool_name"] = f"{key}_{server_name}"
                        all_data.append(snap)

        df = pd.DataFrame(all_data).sort_values(["pool_name", "time"])
        all_seeds_metrics[current_seed] = df
        current_seed = get_seed()
        seed_used.append(current_seed)

    # -------------------- Grafici globali --------------------
    total_percentiles_waits_security = np.percentile(total_percentiles_waits_security, 90)
    total_percentiles_waits_check_in = np.percentile(total_percentiles_waits_check_in, 90)
    print(f"90th percentile waiting for security global: {total_percentiles_waits_security:.2f} seconds")
    print(f"90th percentile waiting for check in global: {total_percentiles_waits_check_in:.2f} seconds")

    metrics = ["avg_utilization", "avg_waiting_time", "avg_response_time", "avg_queue_population"]

    all_pools = set()
    for df in all_seeds_metrics.values():
        all_pools.update(df["pool_name"].unique())

    for pool in all_pools:
        if pool == "daily_percentile_90_wait":
            for column, total_val in [("security", total_percentiles_waits_security),
                                      ("check_in", total_percentiles_waits_check_in)]:
                plt.figure(figsize=(12, 6))
                for seed, df in all_seeds_metrics.items():
                    df_pool = df[df["pool_name"] == pool]
                    if df_pool.empty:
                        continue
                    df_grouped = df_pool.groupby("time")[column].mean().reset_index()
                    plt.plot(df_grouped["time"], df_grouped[column])

                plt.axhline(y=total_val, color="red", linestyle="--", linewidth=2,
                            label=f"Global 90° perc = {total_val:.2f}")
                if column == "check_in":
                    plt.axhline(y=955.0, color="black", linestyle="--", linewidth=2,
                                label=f"Target= {955.0:.2f}")
                else :
                    plt.axhline(y=340.0, color="black", linestyle="--", linewidth=2,
                                label=f"Target= {340.0:.2f}")

                time_slots = [
                    (0, 359 * 60 + 59, "night"),
                    (360 * 60, 539 * 60 + 59, "morning"),
                    (540 * 60, 719 * 60 + 59, "late_morning"),
                    (720 * 60, 899 * 60 + 59, "early_afternoon"),
                    (900 * 60, 1139 * 60 + 59, "late_afternoon"),
                    (1140 * 60, 1319 * 60 + 59, "evening"),
                    (1320 * 60, 1440 * 60 + 59, "late_evening"),
                ]
                ymin, ymax = plt.ylim()
                for start, _, label in time_slots:
                    plt.axvline(x=start, color="green", linestyle="--", linewidth=1.5)
                    plt.text(start, ymin - (ymax * 0.05), label, rotation=90,
                             verticalalignment="top", horizontalalignment="center",
                             fontsize=9, color="green")

                plt.xlabel("Tempo (secondi)")
                plt.ylabel("90th percentile waiting time")
                plt.title(f"Andamento 90° percentile per {column} (confronto seed)")
                plt.legend()
                plt.grid(True)
                plt.tight_layout()

                global_dir = f"90th_percentile_{column}_waits{MODEL_TYPE}"
                os.makedirs(global_dir, exist_ok=True)
                plt.savefig(os.path.join(global_dir, f"{pool}_{column}.png"))
                plt.close()

        else:
            for metric in metrics:
                plt.figure(figsize=(12, 6))
                for seed, df in all_seeds_metrics.items():
                    df_pool = df[df["pool_name"] == pool]
                    if df_pool.empty:
                        continue
                    df_grouped = df_pool.groupby("time")[metric].mean().reset_index()
                    plt.plot(df_grouped["time"], df_grouped[metric])

                plt.xlabel("Tempo")
                plt.ylabel(metric)
                plt.title(f"Andamento di {metric} per {pool} (confronto seed)")
                plt.legend()
                plt.grid(True)
                plt.tight_layout()

                global_dir = "global_metrics_" + MODEL_TYPE
                os.makedirs(global_dir, exist_ok=True)
                plt.savefig(os.path.join(global_dir, f"{pool}_{metric}.png"))
                plt.close()


def infinite_horizon_run():
    # Inizializza il seed
    current_seed = 754321986
    seed_used.append(current_seed)
    plant_seeds(current_seed)

    # Avvia simulazione
    sim = AirportSimulation(
        end_time=float('inf'),
        sampling_rate=BATCH_DIM,
        type_simulation="infinite",
        batch_num=BATCH_NUM,
        model_type = MODEL_TYPE,
    )
    metrics = sim.run()

    # -------------------- Converti in DataFrame unico --------------------
    all_data = []
    for key in metrics.keys():
        if isinstance(metrics[key], list):
            for snap in metrics[key]:
                snap["pool_name"] = key
                all_data.append(snap)
        else:  # caso multi server multi queue
            for server_name, server_snaps in metrics[key].items():
                for snap in server_snaps:
                    snap["pool_name"] = f"{key}_{server_name}"
                    all_data.append(snap)

    df = pd.DataFrame(all_data)
    df = df.sort_values(["pool_name", "time"])

    df["batch"] = df.groupby("pool_name").cumcount() + 1

    # --- Crea cartella ---
    out_dir = "infinite_plots"
    os.makedirs(out_dir, exist_ok=True)

    # -------------------- Grafici per singolo pool --------------------
    pool_names = df["pool_name"].unique()

    for pool in pool_names:
        df_pool = df[df["pool_name"] == pool]
        x = df_pool["batch"]

        plt.figure(figsize=(12, 6))

        plt.subplot(2, 2, 1)
        plt.plot(x, df_pool["avg_utilization"], label="Utilizzazione media")
        plt.xlabel("Batch")
        plt.ylabel("Utilizzazione")
        plt.title(f"Pool: {pool} — Utilizzazione")
        plt.grid(True)

        plt.subplot(2, 2, 2)
        plt.plot(x, df_pool["avg_waiting_time"], label="Tempo medio di attesa", color="orange")
        plt.xlabel("Batch")
        plt.ylabel("Attesa (s)")
        plt.title(f"Pool: {pool} — Tempo medio di attesa")
        plt.grid(True)

        plt.subplot(2, 2, 3)
        plt.plot(x, df_pool["avg_response_time"], label="Tempo medio di risposta", color="green")
        plt.xlabel("Batch")
        plt.ylabel("Risposta (s)")
        plt.title(f"Pool: {pool} — Tempo medio di risposta")
        plt.grid(True)

        plt.subplot(2, 2, 4)
        plt.plot(x, df_pool["avg_queue_population"], label="Popolazione media in coda", color="purple")
        plt.xlabel("Batch")
        plt.ylabel("Lq")
        plt.title(f"Pool: {pool} — Popolazione media in coda")
        plt.grid(True)

        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, f"{pool}_metrics.png"))
        plt.close()

    # -------------------- Grafico comparativo tra pool --------------------
    plt.figure(figsize=(12, 6))
    for pool in pool_names:
        df_pool = df[df["pool_name"] == pool]
        plt.plot(df_pool["batch"], df_pool["avg_utilization"], label=pool)

    plt.xlabel("Batch")
    plt.ylabel("Utilizzazione media")
    plt.title("Utilizzazione media per Pool per batch")
    plt.legend()
    plt.grid(True)
    plt.savefig(os.path.join(out_dir, "all_pools_utilization.png"))
    plt.close()

    return df



if __name__ == '__main__':

    if INFINITE_HORIZON:
        infinite_horizon_run()

    elif FINITE_HORIZON:
        finite_horizon_run()

    else:
        raise ValueError("Errore: Nessun orizzonte di simulazione selezionato")